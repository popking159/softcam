#!/bin/sh

CAMNAME="oscam-icam"

remove_tmp() {
  rm -rf /tmp/.oscam  /tmp/oscam*
}

case "$1" in
start)
  echo "[SCRIPT] $1: $CAMNAME"
  remove_tmp
  touch /tmp/.emu.info
  echo ${CAMNAME} >/tmp/.emu.info
  /usr/bin/${CAMNAME} -b -c /etc/tuxbox/config/${CAMNAME} --pidfile /tmp/${CAMNAME}.pid --restart 2 &
  ;;
stop)
  echo "[SCRIPT] $1: $CAMNAME"
  killall -9 ${CAMNAME} 2>/dev/null
  remove_tmp
  ;;
restart)
  $0 stop
  sleep 2
  $0 start
  exit
  ;;
*)
  $0 stop
  exit 0
  ;;
esac

exit 0
