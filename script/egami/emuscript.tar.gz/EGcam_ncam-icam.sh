#!/bin/sh

CAMNAME="ncam-icam"

remove_tmp() {
	rm -rf /tmp/*.info* /tmp/*.tmp*
}

case "$1" in
start)
	echo "[SCRIPT] $1: $CAMNAME"
	remove_tmp
	/usr/bin/${CAMNAME} --config-dir /etc/tuxbox/config/${CAMNAME} --daemon --pidfile /tmp/${CAMNAME}.pid --restart 2 &
	;;
stop)
	echo "[SCRIPT] $1: $CAMNAME"
	killall -9 ${CAMNAME} 2>/dev/null
	sleep 1
	remove_tmp
	;;
*)
	$0 stop
	exit 0
	;;
esac

exit 0
