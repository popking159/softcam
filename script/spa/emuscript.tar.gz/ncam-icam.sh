#!/bin/sh

CAMD_ID=3333
CAMD_NAME="ncam-icam"

INFOFILE_A=ecm.info
INFOFILE_B=ecm1.info
INFOFILE_C=ecm2.info
INFOFILE_D=ecm3.info
INFOFILE_E=ecm4.info
INFOFILE_F=ecm5.info
#Expert window
INFOFILE_LINES=1111111111000000
#Zapp after start
REZAPP=0

########################################

logger $0 $1
echo $0 $1

remove_tmp () {
  rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*mbox* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/*ncam* /tmp/.ncam
}

case "$1" in
  start)
  remove_tmp
  /usr/bin/ncam-icam --config-dir /etc/tuxbox/config/ncam-icam --daemon --pidfile /tmp/ncam-icam.pid --restart 2 &
  ;;
  stop)
  killall -9 ncam-icam 2>/dev/null
  sleep 2
  remove_tmp
  ;;
  *)
  $0 stop
  exit 0
  ;;
esac

exit 0
